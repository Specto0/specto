
API_KEY = "2ff0aa1aaed2be36cf597b8bbbc0dd94"
BASE_URL = "https://api.themoviedb.org/3"
