from fastapi import FastAPI, Depends
from app.routers import auth
from app.schemas.user import UserRead

app = FastAPI(title="Specto API")

# Incluir router de autenticação
app.include_router(auth.router)

# Endpoint protegido de teste
@app.get("/me", response_model=UserRead)
async def me(user = Depends(auth.get_current_user)):
    return {"id": user.id, "username": user.username, "email": user.email}

# Log das rotas no arranque (debug)
@app.on_event("startup")
async def _debug_routes():
    print("Rotas carregadas:")
    for r in app.routes:
        try:
            print(r.path, list(r.methods))
        except Exception:
            pass
